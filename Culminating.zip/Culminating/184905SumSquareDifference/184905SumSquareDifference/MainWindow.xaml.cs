﻿/*Austin McKee
 * June 17, 2019
 * this program adds together the sum of all the numbers 1-100 squared but subtracts that from the square of all numbers added together 
 * (1^2 + 2^2 + 3^2, etc) versus (1+2+3+4+5)^2
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184905SumSquareDifference
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Int32 SumSquared;
        
        Int32 FinalDifference;

        public MainWindow()
        {
            InitializeComponent();
            for (int i = 1; i < 101; i++)
            {
                FinalDifference -= i*i;
            }
            for(int j = 1; j<101; j++)
            {
                SumSquared += j;
            }
            SumSquared = SumSquared * SumSquared;
            //MessageBox.Show(SumSquared.ToString());
            FinalDifference += SumSquared;
            Output.Content = FinalDifference;

        }
        
    }
}
