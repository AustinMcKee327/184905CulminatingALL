﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184905LargeSums
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string output;
        string num1;
        string num2;
        string[] s;
        public MainWindow()
        {
            InitializeComponent();
            output = "";
            System.IO.StreamReader NumberReader = new System.IO.StreamReader("Numbers.txt");
            for (int i = 0; i < 2; i++)
            {
                output = NumberReader.ReadLine();
                string[] s = output.Split(',');
                for(int j = 0; j < 5; j++)
                {
                    
                    s[5] = num1;
                    s[10] = num2;
                }
                
            }
            
        }
    }
}
