﻿/*Austin McKee
 * June 17, 2019
 * This program is supposed to read from the text file, poker.txt and tell me how many times pplayer one wins based upon poker rules. 
 * However, I could not get the program to fully work. It will read and assgin the values of each hand correctly, but when both
 * players get a pair or a three of a kind, it cannot correctly identify who wins.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184905PokerHands
{
   public enum suits {Clubs, Diamonds, Heart, Spades };
    public enum face {Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King };
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string debugoutput = "";
        int gameCount = 0;
        int Player1Count;
        string line;
        string hand1;
        string hand2;
        int LoseCounter;
        int ScoreP1;
        int ScoreP2;
        int HandChecker = 0;
        System.IO.StreamReader sr = new System.IO.StreamReader("poker.txt");
        System.IO.StreamReader srt = new System.IO.StreamReader("TestRoyalFlush.txt");
        int countLinesOfText = 0;
        

        string handCheck = "Game\tPlayer1\tPlayer2\n";
        public MainWindow()
        {
            InitializeComponent();
            
            //temp = sr.ToString();
            //temp1 = temp.Split(' ').ToString();
            //MessageBox.Show(temp1);
            //for(int i= 1; i<1001; i++)
            while(!sr.EndOfStream)
            {
                
                line = sr.ReadLine().ToString();
                countLinesOfText++;
                hand1 = line.Substring(0, 14);
                hand2 = line.Substring(15, 14);
                
                

                string[] Hand1Cards = new string[5];
                suits[] Hand1Suites = new suits[5];
                face[] Hand1Face = new face[5];
                string[] Hand2Cards = new string[5];
                suits[] Hand2Suites = new suits[5];
                face[] Hand2Face = new face[5];
                for (int j = 0; j < Hand1Cards.Length; j++)
                {
                    Hand1Cards[j] = hand1.Substring(j * 3, 2);
                    switch (Hand1Cards[j][0])
                    {
                        case 'A': Hand1Face[j] = face.Ace; break;
                        case '2': Hand1Face[j] = face.Two; break;
                        case '3': Hand1Face[j] = face.Three; break;
                        case '4': Hand1Face[j] = face.Four; break;
                        case '5': Hand1Face[j] = face.Five; break;
                        case '6': Hand1Face[j] = face.Six; break;
                        case '7': Hand1Face[j] = face.Seven; break;
                        case '8': Hand1Face[j] = face.Eight; break;
                        case '9': Hand1Face[j] = face.Nine; break;
                        case 'T': Hand1Face[j] = face.Ten; break;
                        case 'J': Hand1Face[j] = face.Jack; break;
                        case 'Q': Hand1Face[j] = face.Queen; break;
                        case 'K': Hand1Face[j] = face.King; break;
                    }
                    switch (Hand1Cards[j][1]) {
                        case 'D': Hand1Suites[j] = suits.Diamonds; break;
                        case 'H': Hand1Suites[j] = suits.Heart; break;
                        case 'C': Hand1Suites[j] = suits.Clubs; break;
                        case 'S': Hand1Suites[j] = suits.Spades; break;
                    }
                    

               //     MessageBox.Show(Hand1Face[j].ToString() + Hand1Suites[j].ToString());
                }
                for (int j = 0; j < Hand2Cards.Length; j++)
                {
                    Hand2Cards[j] = hand2.Substring(j * 3, 2);
                    switch (Hand2Cards[j][0])
                    {
                        case 'A': Hand2Face[j] = face.Ace; break;
                        case '2': Hand2Face[j] = face.Two; break;
                        case '3': Hand2Face[j] = face.Three; break;
                        case '4': Hand2Face[j] = face.Four; break;
                        case '5': Hand2Face[j] = face.Five; break;
                        case '6': Hand2Face[j] = face.Six; break;
                        case '7': Hand2Face[j] = face.Seven; break;
                        case '8': Hand2Face[j] = face.Eight; break;
                        case '9': Hand2Face[j] = face.Nine; break;
                        case 'T': Hand2Face[j] = face.Ten; break;
                        case 'J': Hand2Face[j] = face.Jack; break;
                        case 'Q': Hand2Face[j] = face.Queen; break;
                        case 'K': Hand2Face[j] = face.King; break;
                    }
                    switch (Hand2Cards[j][1])
                    {
                        case 'D': Hand2Suites[j] = suits.Diamonds; break;
                        case 'H': Hand2Suites[j] = suits.Heart; break;
                        case 'C': Hand2Suites[j] = suits.Clubs; break;
                        case 'S': Hand2Suites[j] = suits.Spades; break;
                    }


                    //     MessageBox.Show(Hand2Face[j].ToString() + Hand1Suites[j].ToString());
                }

                Array.Sort(Hand1Face);
                string output = "";
                for (int i = 0; i < Hand1Face.Length; i++)
                {
                    output += Hand1Face[i];
                }
                //MessageBox.Show(output);
                //MessageBox.Show((face.Ace - face.King).ToString());
                ScoreP1 = 0;
                ScoreP2 = 0;
                if (isOnePair(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 2;
                   
                }
                if (isTwoPairs(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 3;
                }
                if (isThreeOfAKind(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 4;
                }
                if (isStraight(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 5;
                }
                if (isFlush(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 6;
                }
                if (isFullHouse(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 7;
                }
                if (isFourOfAKind(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 8;
                }
                if (isStraightFlush(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 9;
                }
                if (isRoyalFlush(Hand1Face, Hand1Suites))
                {
                    ScoreP1 = 10;
                }
                if(ScoreP1 == 0)
                {
                    ScoreP1 = 1;
                }//Player One Score Check


                /*Check and record the type of hand*/
                switch (ScoreP1)
                {
                    case 10: handCheck += countLinesOfText.ToString() + "\tRoyal Flush"; break;
                    case 9: handCheck += countLinesOfText.ToString() + "\tStraight Flush"; break;
                    case 8: handCheck += countLinesOfText.ToString() + "\tFour of a kind"; break;
                    case 7: handCheck += countLinesOfText.ToString() + "\tFull House"; break;
                    case 6: handCheck += countLinesOfText.ToString() + "\tFlush"; break;
                    case 5: handCheck += countLinesOfText.ToString() + "\tStraight"; break;
                    case 4: handCheck += countLinesOfText.ToString() + "\tThree of a Kind"; break;
                    case 3: handCheck += countLinesOfText.ToString() + "\tTwo Pairs"; break;
                    case 2: handCheck += countLinesOfText.ToString() + "\tOne Pair"; break;
                    case 1: handCheck += countLinesOfText.ToString() + "\tHighest Card"; break;
                    default: handCheck += countLinesOfText.ToString() +"\tUnknown hand"; break;
                    
                }
                /*Recorded player one hand*/
                Array.Sort(Hand2Face);
                string output2 = "";
                for (int i = 0; i < Hand2Face.Length; i++)
                {
                    output2 += Hand2Face[i];
                }
                //MessageBox.Show(output2);

                if (isOnePair(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 2;
                    
                }
                if (isTwoPairs(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 3;
                }
                if (isThreeOfAKind(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 4;
                }
                if (isStraight(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 5;
                }
                if (isFlush(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 6;
                }
                if (isFullHouse(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 7;
                }
                if (isFourOfAKind(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 8;
                }
                if (isStraightFlush(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 9;
                }
                if (isRoyalFlush(Hand2Face, Hand2Suites))
                {
                    ScoreP2 = 10;
                }
                if (ScoreP2 == 0)
                {
                    ScoreP2 = 1;
                }// Player Two Score Check

                /*Check and record the type of hand*/
                switch (ScoreP2)
                {
                    case 10: handCheck += "\t" + "Royal Flush\n"; break;
                    case 9: handCheck += "\t" + "Straight Flush\n"; break;
                    case 8: handCheck += "\t" + "Four of a kind\n"; break;
                    case 7: handCheck +=  "\tFull House\n"; break;
                    case 6: handCheck +=  "\tFlush\n"; break;
                    case 5: handCheck +=  "\tStraight\n"; break;
                    case 4: handCheck +=  "\tThree of a Kind\n"; break;
                    case 3: handCheck +=  "\tTwo Pairs\n"; break;
                    case 2: handCheck +=  "\tOne Pair\n"; break;
                    case 1: handCheck +=  "\tHighest Card\n"; break;
                    default: handCheck += "\t" + "Unknown hand\n";break;
                }
                /*Recorded player one hand*/

                if (ScoreP1 > ScoreP2)
                {
                    
                    Player1Count++;
                    
                    debugoutput += gameCount.ToString() + "\tPlayer1" + "\t" + Player1Count.ToString() + "\n";
                }
                else if (ScoreP1 == ScoreP2)
                {
                   
                    

                    if (Hand1Face[4]>Hand2Face[4])
                    {
                        debugoutput += gameCount.ToString() + "\tPlayer1" + "\t" + Player1Count.ToString() + "\n";
                        
                        Player1Count++;
                        
                    }
                    else { LoseCounter++; }

                    
                }
                else
                {
                    LoseCounter++;
                }
                //MessageBox.Show(ScoreP1.ToString() +" " + ScoreP2.ToString());
                gameCount++;
            }
            //Clipboard.SetText(debugoutput);
            Clipboard.SetText(handCheck);
            WinnerLabel.Content = "Player 1 wins This many times: " + Player1Count + Environment.NewLine + LoseCounter;
            MessageBox.Show(countLinesOfText.ToString());
        }

        public bool isRoyalFlush(face[] f, suits[] s)
        {
            bool RoyalFlush = false;
            if(s[0] == s[1] && s[0] == s[2] && s[0] == s[3] && s[0] == s[4])
            {
                if(f[0] - f[4] == -12 && f[1] - f[2] == -1 && f[2] - f[3] == -1 && f[3] - f[4] == -1)
                {
                    RoyalFlush = true;
                }
            }
            return RoyalFlush;
        }//Check for true / false, true means a Royal Flush is happening
        public bool isStraightFlush(face[] f, suits[] s)
        {
            bool StraightFlush = false;
            if (s[0] == s[1] && s[0] == s[2] && s[0] == s[3] && s[0] == s[4])
            {
                if (f[0] - f[1] == -1 && f[1] - f[2] == -1 && f[2] - f[3] == -1 && f[3] - f[4] == -1)
                {
                    StraightFlush = true;
                }
            }
            return StraightFlush;
        }//Check for true / false, true means a straight flush occurs
        public bool isFourOfAKind(face[] f, suits[] s)
        {
            bool FOAK = false;
            if ((f[1] == f[2]))
            {
                if (f[1] == f[3])
                {
                    if (f[1] == f[4])
                    {
                        FOAK = true;
                    }
                }
            }
            if (f[0] == f[1])
            {
                if (f[0] == f[2])
                {
                    if (f[0] == f[3])
                    {
                        FOAK = true;
                    }
                }
            }
                    return FOAK;


        }//Check for true / false, true means Four of a kind happens
        public bool isFullHouse(face[]  f, suits[] s)
        {
            bool FullHouse = false;
            if (f[0] == f[1])
            {
                if (f[2] == f[4])
                {
                    if (f[0] == f[1])
                    {
                        FullHouse = true;
                    }
                }
            }
            if (f[2] == f[3])
            {
                if (f[2] == f[4])
                {
                    if (f[0] == f[1])
                    {
                        FullHouse = true;
                    }
                }
            }
            return FullHouse;
        } //Check for true / false, true means Full House occurs
        public bool isFlush(face[] f, suits[] s)
        {
            bool Flush = false;
            if(s[0] == s[1] && s[0] == s[2] && s[0] == s[3] && s[0] == s[4])
            {
                Flush = true;
            }
            return Flush;
        }//check for true / false if flush occurs        
        public bool isStraight(face[]f, suits[] s)
        {
            bool Straight = false;
            if(f[0] - f[1] == -1 && f[1] - f[2] == -1 && f[2] - f[3] == -1 && f[3] - f[4] == -1)
            {
                Straight = true;
            }
            return Straight;
        } //Check for true / false, true means straight occurs
        public bool isThreeOfAKind(face[]f, suits[] s)
        {
            bool TOAK = false;
            if (f[0] == f[1])
            {
                if (f[0] == f[2])
                {
                    TOAK = true;
                }
            }
            if (f[2] == f[3])
            {
                if (f[2] == f[4])
                {
                    TOAK = true;
                }
            }
            if (f[1] == f[2])
            {
                if (f[2] == f[3])
                {
                    TOAK = true;
                }
            }
            return TOAK;
        }
        public bool isTwoPairs(face[]f, suits[] s)
        {
            bool TwoPairs = false;
            if(f[0] == f[1] && f[2] == f[3])
            {
                 TwoPairs = true;
            }
            if (f[1] == f[2] && f[3] == f[4])
            {
                TwoPairs = true;
            }
            if (f[0] == f[1] && f[3] == f[4])
            {
                TwoPairs = true;
            }
            return TwoPairs;
        }
        public bool isOnePair(face[]f, suits[] s)
        {
            bool OnePair = false;
            if (f[0] == f[1])
            {
                OnePair = true;
                
                HandChecker = 1;
            }
            if (f[1] == f[2])
            {
                OnePair = true;
                HandChecker = 2;
            }
            if (f[2] == f[3])
            {
                OnePair = true;
                HandChecker = 3;
            }
            if (f[3] == f[4])
            {
                OnePair = true;
                HandChecker = 4;
            }
            return OnePair;
            
        }

        

    }
}
